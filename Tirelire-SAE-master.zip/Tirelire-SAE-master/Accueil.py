from tkinter import *
from tkinter.messagebox import showerror, showinfo
from listeinscrits import listeInscrit
import threading # pour la gestion timers

# Configuration de la classe Profils afin qu'il n'y ait pas d'utilisateur identiques et que tout soit complété
class Profils:
    def __init__(self, prenom, nom, montant_depart, argent_poche_hebdo, argent_poche_mens, paiement):
        self.prenom = prenom
        self.nom = nom
        self.montant_depart = montant_depart
        self.argent_poche_hebdo = argent_poche_hebdo
        self.argent_poche_mens = argent_poche_mens
        self.paiement = paiement

    def __eq__(self, other):
        return self.prenom == other.prenom and self.nom == other.nom

    # Méthode statique pour vérifier si un profil appartient à une liste
    @staticmethod
    def appartient(liste, valeur):
        for profil in liste:
            if profil == valeur:
                return True
        return False
    
#methode pour incrementer le solde
 
    def incrementer_solde(self, intervalle):
        if intervalle == 'hebdo':  # Incrémentation hebdomadaire
            self.montant_depart += self.argent_poche_hebdo
        elif intervalle == 'mensuel':  # Incrémentation mensuelle
            self.montant_depart += self.argent_poche_mens


# Liste globale des profils
listePersonne = []

#methode et fonction pour incrementer le solde regulierement

def incrementer_soldes(intervalle):
    global listePersonne
    for profil in listePersonne:
        profil.incrementer_solde(intervalle)
    # Relance le timer (hebdomadaire : 7 jours * 24h * 3600s, mensuel : 30 jours * 24h * 3600s)
    delai = 7 * 24 * 3600 if intervalle == 'hebdo' else 30 * 24 * 3600
    threading.Timer(delai, incrementer_soldes, args=(intervalle,)).start()

# Fonction pour valider les informations entrées
def Valider():
    global listePersonne
    if prenomEntre.get() and nomEntre.get() and montant_departEntre.get() and argent_pochehebdoEntre.get() and argent_pochemensEntre.get() and paiementEntre.get():
        pf = Profils(
            prenomEntre.get(),
            nomEntre.get(),
            float(montant_departEntre.get()),
            float(argent_pochehebdoEntre.get()),
            float(argent_pochemensEntre.get()),
            paiementEntre.get(),
        )
        if Profils.appartient(listePersonne, pf):
            showerror(title="Formulaire invalide", message="Ce profil existe déjà.")
        else:
            listePersonne.append(pf)
            showinfo(title="Validation réussie", message=f"{prenomEntre.get()} a bien été ajouté.")
    else:
        showerror(title="Formulaire invalide", message="Vous n'avez pas tout renseigné.")

# Fonction pour réinitialiser les champs
def Reinitialiser():
    prenomEntre.delete(0, END)
    nomEntre.delete(0, END)
    montant_departEntre.delete(0, END)
    argent_pochehebdoEntre.delete(0, END)
    argent_pochemensEntre.delete(0, END)
    paiementEntre.delete(0, END)

# Création de la fenêtre principale
fen = Tk()
fen.geometry("300x320+300+150")
fen.title("Page d'inscription")

contenu = Canvas(fen, bg="#FF7800")

# Polices des éléments
fontLabel = 'arial 13 bold'
fontEntre = 'arial 11 bold'

# Création des labels
prenom = Label(contenu, text="Le prénom de votre enfant :", font=fontLabel, fg='white', bg="#FF7800")
nom = Label(contenu, text="Le nom de votre enfant :", font=fontLabel, fg='white', bg="#FF7800")
montant_depart = Label(contenu, text="Le montant de départ de votre enfant :", font=fontLabel, fg='white', bg="#FF7800")
argent_pochehebdo = Label(contenu, text="L'argent de poche hebdomadaire :", font=fontLabel, fg='white', bg="#FF7800")
argent_pochemens = Label(contenu, text="L'argent de poche mensuelle :", font=fontLabel, fg='white', bg="#FF7800")
paiement = Label(contenu, text="Le mode de paiement :", font=fontLabel, fg='white', bg="#FF7800")
Validation = Label(contenu, text="Entrez les informations ici :", font=fontLabel, fg='#FF7800', bg="white")

# Création des champs de saisie
prenomEntre = Entry(contenu, font=fontEntre)
nomEntre = Entry(contenu, font=fontEntre)
montant_departEntre = Entry(contenu, font=fontEntre)
argent_pochehebdoEntre = Entry(contenu, font=fontEntre)
argent_pochemensEntre = Entry(contenu, font=fontEntre)
paiementEntre = Entry(contenu, font=fontEntre)

# Placement des labels
Validation.grid(row=0, column=0, columnspan=2)
prenom.grid(row=1, column=0, sticky=E, padx=5, pady=5)
nom.grid(row=2, column=0, sticky=E, padx=5, pady=5)
montant_depart.grid(row=3, column=0, sticky=E, padx=5, pady=5)
argent_pochehebdo.grid(row=4, column=0, sticky=E, padx=5, pady=5)
argent_pochemens.grid(row=5, column=0, sticky=E, padx=5, pady=5)
paiement.grid(row=6, column=0, sticky=E, padx=5, pady=5)

# Placement des champs de saisie
prenomEntre.grid(row=1, column=1, padx=5, pady=5)
nomEntre.grid(row=2, column=1, padx=5, pady=5)
montant_departEntre.grid(row=3, column=1, padx=5, pady=5)
argent_pochehebdoEntre.grid(row=4, column=1, padx=5, pady=5)
argent_pochemensEntre.grid(row=5, column=1, padx=5, pady=5)
paiementEntre.grid(row=6, column=1, padx=5, pady=5)

# Création des boutons
b1 = Button(fen, text="Valider", command=Valider, width=10, fg='#FF7800', bg='white')
b2 = Button(fen, text="Réinitialiser", command=Reinitialiser, width=10, fg='#FF7800', bg='white')
b3 = Button(fen, text="Voir la liste", command=lambda: listeInscrit(fen,listePersonne), width=10, fg='#FF7800', bg='white')

# Placement des boutons
b1.grid(row=4, column=0, pady=5)
b2.grid(row=5, column=0, pady=5)
b3.grid(row=6, column=0, pady=5)

# Placement du canvas
contenu.grid(row=0, column=0, padx=5, pady=5)

#utilise des timers pour incrementer le soldes
incrementer_soldes('hebdo')  # 
incrementer_soldes('mensuel') 

# Pour afficher la fenêtre
fen.mainloop()
